from MRPudpp import udpp

def main():
    udpp.run()