from MRPudpp import udpp

if __name__ == '__main__':
    udpp.run()