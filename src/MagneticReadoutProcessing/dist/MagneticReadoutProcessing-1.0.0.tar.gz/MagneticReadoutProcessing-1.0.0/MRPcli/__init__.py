#import cli
from MRPcli import cli


def main():
    cli.run()