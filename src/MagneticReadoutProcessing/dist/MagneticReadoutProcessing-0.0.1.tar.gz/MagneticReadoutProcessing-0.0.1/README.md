# MagneticReadoutProcessing

This library was created for the Low-Field MRI project and allows processing of data measured by magnetic field sensors.
The focus is on visualization, followed by the provision of simple interfaces to work with this data.
In general its possible to use this lib on all kinds of data.